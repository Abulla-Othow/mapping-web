
// Task-1: visualize an earthquake data set.

// Get the Earthquake Json

// Store our API endpoint inside allEarthquakeURL

var allEarthquakeURL = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson"

// Our boundary coordinate
var bound_coordinate = "https://raw.githubusercontent.com/fraxen/tectonicplates/master/GeoJSON/PB2002_boundaries.json"


// Import & Visualize the Data
// =====================================================
// Create a map using Leaflet that plots all of        =
// the earthquakes from your data set based on their    =
// longitude and latitude.                              =
//=======================================================


// Define a markerSize function based on the magnitude scale  of the Earthquake.
function markerSize( magnitudeScale) {
    return magnitudeScale * 3; //Times 3 just to make it more visible. 
  };

//Define a layer group for the Earthquakes in order to group layers.
var earthquakes = new L.LayerGroup();

// LOAD IN GEOJSON DATA (Perform a GET request to the  allEarthquakeURL)
d3.json(allEarthquakeURL, function(geoJson) {
    L.geoJSON(geoJson.features, {
        pointToLayer: function(geoJsonPoint, latlng) {
            return L.circleMarker(latlng, {radius: markerSize(geoJsonPoint.properties.mag)});
        },
        style: function (geoJsonFeature) {
            return {
                fillColor: Color(geoJsonFeature.properties.mag),
                fillOpacity: 0.8,
                weight: 0.1,
                color: 'black'
            }
        },
        onEachFeature: function(feature, layer){
            layer.bindPopup(
               "<h4 style='text-align: center;'>" + new Date(feature.properties.time) +
               "</h4> <hr> <h5 style= 'style='text-align:center; '>" + feature.properties.title + "</h5");
        }
    }).addTo(earthquakes);
    createMap(earthquakes);
});

// Create a layer group
var boundary = new L.layerGroup();
    
d3.json(bound_coordinate, function(geoJson){
    L.geoJSON(geoJson.features, {
        style: function (geoJsonFeature){
            return {
                weight: 2,
                color: 'magenta'
            }
        },
    }).addTo(boundary)
})
// use color wheel (https://www.sessions.edu/color-calculator/)
function Color(magnitudeScale){
    if (magnitudeScale > 5) {
        return '#cc2d2d'
    } else if (magnitudeScale >4){
        return '#cf7730'
    } else if (magnitudeScale > 3){
        return '#4a3727'
    } else if (magnitudeScale > 2) {
        return '#fffdb5'
    } else if (magnitudeScale) {
        return '#118c57'
    } else {
        return '#b5ebd9'
    }
};

// Creat a Map

function createMap() {

    // Let add tileLayers and street map from OpenStreetMap

    var highContrastMap = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox.high-contrast',
        accessToken:  "pk.eyJ1IjoiYWJ1bGxhIiwiYSI6ImNqbHgxeWlhZDBlbm8zcG81emFqNzZjczIifQ.PlCb1I5ED-pVor6nGSXS1g"
    });

    var streetMap = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox.streets',
        
        accessToken:  "pk.eyJ1IjoiYWJ1bGxhIiwiYSI6ImNqbHgxeWlhZDBlbm8zcG81emFqNzZjczIifQ.PlCb1I5ED-pVor6nGSXS1g"
    });

    var darkMap = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox.dark',
        accessToken: "pk.eyJ1IjoiYWJ1bGxhIiwiYSI6ImNqbHgxeWlhZDBlbm8zcG81emFqNzZjczIifQ.PlCb1I5ED-pVor6nGSXS1g"
    });

    var satellite = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox.satellite',
        accessToken: "pk.eyJ1IjoiYWJ1bGxhIiwiYSI6ImNqbHgxeWlhZDBlbm8zcG81emFqNzZjczIifQ.PlCb1I5ED-pVor6nGSXS1g"
    });
  // Define a baseMaps object to hold our base layers
    var baseLayers = {
        "High Contrast": highContrastMap,
        "Street": streetMap,
        "Dark": darkMap,
        "Satellite": satellite
    };

      // Create overlay object to hold our overlay layer

    var overlays = {
        "Earthquakes": earthquakes,
        "Boundaries": boundary,
    };
// Get Leaflet Map into Browser 
    var map = L.map('map', {
        center: [35, -99],
        zoom: 5,
        minZoom: 2,
        MaxZoom: 18,
        layers: [streetMap, earthquakes, boundary]
    });
 // Create a layer control
  // Pass in our baseMaps and overlayMaps
  // Add the layer control to the map

    L.control.layers(baseLayers, overlays).addTo(map);
    var legend = L.control({ position: 'topright' });
//  Add legend to the graph
    legend.onAdd = function(map) {
        var div = L.onAdd

    }
    legend.onAdd = function (map) {
            // Add Utility functions to indicate the intensity of Earthquake across the boundaries.
        var div = L.DomUtil.create('div', 'info legend'),
            magnitude = [0, 1, 2, 3, 4, 5],
            labels = [];

        div.innerHTML += "<h4 style='margin:4px'>Magnitude</h4>"

        for (var i = 0; i < magnitude.length; i++) {
            div.innerHTML +=
                '<i style="background:' + Color(magnitude[i] + 1) + '"></i> ' +
                magnitude[i] + (magnitude[i + 1] ? '&ndash;' + magnitude[i + 1] + '<br>' : '+');
        }

        return div;
    };
    legend.addTo(map)
}






